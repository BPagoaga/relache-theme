<?php include('functions.php') ?>
<?php include('header.php'); ?>

	<main role="main" class="programmation">

		<?php include('ariane.php'); ?>

		<h1>programmation relache 2015</h1>

		<?php $prog = get_prog(); //récupération de la prog retournée par la fonction get_prog, il s'agit d'un tableau, donc on utilise la boucle foreach ?>

		<?php foreach ($prog as $programmation): ?>

			<article class="programmation">

				<a href="artiste.php?artiste=<?=$programmation['artiste'] ?>">

					<img src="" alt="">
						
					<label style="font-size:1rem" for="">
						<?= $programmation['artiste'] ?>
					</label>

				</a>

				<p>Le <?= $programmation['date'] ?>, <?= $programmation['heure'] ?> à <a href="lieux.php?lieu=<?= $programmation['lieux'] ?>"> <?= $programmation['lieux'] ?></a> </p>
				
				

			</article>

		<?php endforeach ?>

		
	</main> <!-- fin main -->

<?php include('footer.php'); ?>