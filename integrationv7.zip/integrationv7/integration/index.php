<?php include('header.php'); ?>

    <main role="main">
        
        <article class="article-slider">

            <div class="slidervegas" style="height: 400px"></div>
            
        </article>

        <article class="article-newsletter">

            <form action="">
            
                <div class="row">

                    <label class="col-12 col-center col-m-6">Abonnez-vous à la Newsletter</label>

                    <div class="email col-center col-12 col-m-6 row">
                   
                        <input class="col-7" type="email" name="email" id="email" placeholder="Adresse e-mail">

                        <input class="col-2 col-offset-1" type="submit" value="GO">

                    </div>

                </div>

            </form>

        </article>

        <article class="article-relache col-12 col-m-6">

            <section class="section-relache">

                <h2>Qu'est-ce que Relache&nbsp;?</h2>

                    <p>
                        Élu festival local préféré au BDXC Awards 2014, il se déroule depuis 5 ans en pleine période estivale de Juin à Septembre.
                    </p>

                    <div class="arrow">
                        <span></span>
                    </div>

                    <div class="center">
                        <a href="#" class="btn">Nos valeurs</a>
                    </div>

            </section>

                <aside>

                    <h2>Suivez-nous !</h2>

                    <section class="playlist">
                    
                        <span></span> <!--image du vinyl-->

                        <h3>la playlist relache</h3>

                        <iframe width="100%" height="200" scrolling="no" frameborder="no" src="https://w.soundcloud.com/player/?url=https%3A//api.soundcloud.com/playlists/1281593&amp;auto_play=false&amp;hide_related=false&amp;show_comments=true&amp;show_user=true&amp;show_reposts=false&amp;visual=true"></iframe>

                    </section>

                    <section class="instagramlive">

                        <h3>instagram #relache 2015</h3>

                        <div id="instafeed"></div>

                        <!--<div class="tagboard-embed" tgb-slug="webdev" tgb-layout="waterfall" tgb-feed-type="default" tgb-toolbar="light" tgb-animation-type="default"></div>-->

                    </section>

                </aside>

        </article>

        <article class="article-actualite col-12 col-m-6">  

            <h2>les dernières news</h2>              

            <section class="article-blog row">

                <a href="#">

                    <div class="thumbnail col-m-3">

                        <img src="img/icons/icontest.jpg" title ="image de test"alt="image de test">

                    </div><!--

                    --><div class="article col-12 col-m-9">

                        <h3>introduction : relache #6</h3>

                        <em>Le 21 Mai 2015</em>

                        <p>Herp derpsum me ler derpus pee. Herpler der derps dee tee merpus derpler? Ler ter herpy derps derpsum?Herp derpsum me ler derpus pee. Herpler der derps dee tee merpus derpler? Ler ter herpy derps derpsum?</p>

                    </div>

                </a>

            </section>

            <section class="article-blog">

                <a href="#">

                    <div class="thumbnail col-m-3">

                        <img src="img/icons/icontest.jpg" title ="image de test"alt="image de test">

                    </div><!--

                    --><div class="article col-12 col-m-9">

                        <h3>introduction : relache #6</h3>

                        <em>Le 21 Mai 2015</em>

                        <p>Herp derpsum me ler derpus pee. Herpler der derps dee tee merpus derpler? Ler ter herpy derps derpsum?Herp derpsum me ler derpus pee. Herpler der derps dee tee merpus derpler? Ler ter herpy derps derpsum? </p>

                    </div>

                </a>

            </section>

            <section class="article-blog">

                <a href="#">

                    <div class="thumbnail col-m-3">

                        <img src="img/icons/icontest.jpg" title ="image de test"alt="image de test">

                    </div><!--

                    --><div class="article col-12 col-m-9">

                        <h3>introduction : relache #6</h3>

                        <em>Le 21 Mai 2015</em>

                        <p>Herp derpsum me ler derpus pee. Herpler der derps dee tee merpus derpler? Ler ter herpy derps derpsum?Herp derpsum me ler derpus pee. Herpler der derps dee tee merpus derpler? Ler ter herpy derps derpsum?</p>

                    </div>

                </a>

            </section>

        </article>

        <article class="article-galerie col-12">

            <h2>Ambiance Relache</h2>

            <section class="galerie row">

                <div class="img1 col-12 col-m-6 col-l-4">
                    <img src="img/slider.svg" alt="galerie relache 2015 bordeaux">
                    <p>Dancing in the street <br>
                    Relache 2015</p>
                </div>

                <div class="img2 col-m-6 col-l-4">
                    <img src="img/slider.svg" alt="galerie relache 2015 bordeaux">
                     <p>Dancing in the street <br>
                    Relache 2015</p>
                </div>

                <div class="img3 col-l-4">
                    <img src="img/slider.svg" alt="galerie relache 2015 bordeaux">
                     <p>Dancing in the street <br>
                    Relache 2015</p>
                </div>

                <div class="center">
                    <a href="#" class="btn">La galerie</a>
                </div>

            </section>

        </article>
        
    </main> <!-- .l-constrained -->
    

<?php include('footer.php'); ?>
