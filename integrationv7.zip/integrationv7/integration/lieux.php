<?php 

include('functions.php');
include('header.php');

if( !empty($_GET) ) {
$lieu=get_lieu($_GET['lieu']); //déclaration de la variable $artiste dans laquelle on rentre la ligne de la table 'artistes' ou le champs 'artiste' équivaut au nom de l'artiste passé dans l'url via a href="artiste.php?artiste=..."
}

?>

	<main role="main" class="lieux">
		
		<?php include('ariane.php'); ?>

		<article class="article-artiste">
		
			<h1><?= $lieu['lieu']; ?></h1>

			<p><?= $lieu['description']; ?></p>



		</article>


	</main>

<?php include('footer.php'); ?>