/**
 * Global variables
 *
 * @author Jonathan Path
 */

// Remove NavBar from iOS
if( !window.location.hash && window.addEventListener ){
    window.addEventListener( "load",function() {
        setTimeout(function(){
            window.scrollTo(0, 0);
        }, 0);
    });
    window.addEventListener( "orientationchange",function() {
        setTimeout(function(){
            window.scrollTo(0, 0);
        }, 0);
    });
}

$(document).ready(function(){

});


//burger/plus : ajout de la classe .active

(function () {

    "use strict";

    var toggles = document.querySelectorAll(".burger, .plus");

    for (var i = toggles.length - 1; i >= 0; i--) {
        var toggle = toggles[i];
        toggleHandler(toggle);
    };

    function toggleHandler(toggle) {
        toggle.addEventListener( "click", function(e) {
            e.preventDefault();
            (this.classList.contains("active") === true) ? this.classList.remove("active") : this.classList.add("active");
        });
    }

})();


//search-form : ajout de la classe active

$("#inpt_search").on('focus', function () {
    $(this).parent('label').addClass('active');
    $('.l-nav').addClass('open-search');

});

$("#inpt_search").on('blur', function () {
    if($(this).val().length == 0) {
        $(this).parent('label').removeClass('active');
        $('.l-nav').removeClass('open-search');
    }
});

//apparition du bouton

//a faire : ne faire apparaitre qu'à partir du mode tablette (inutile sur les smartphones)

$(window).scroll(function() {
    if($(window).scrollTop() > 400) {
        $('a.back-to-top').fadeIn('fast');
    }else{
        $('a.back-to-top').fadeOut('fast');
    }
});

//SMOOTH SCROLL

$('a[href^="#"]').click(function(){
                
            
    //$(this).attr('href');  //this permet ici de recuprer le a sur lequel on clique. Si on mettait 'a', il recupererait tout le temps le sec1  
    
    var href = $(this).attr('href'); //cette variable contient la string sec1, sec2 ou sec3
    var pos = $(href).offset().top; // donne le offset top et le met dans une variable
    //console.log(pos);
    
    
    /*HOMOGNISATION POUR LES VIEUX NAVIGATEURS ET CHROME*/
    
    var nav='html';
    
    if (navigator.userAgent.indexOf('WebKit')>0) {  //s'il y a un webkit => on effectue la boucle, sinon, on utilise la fonction normale
        nav='body';
    }
    
    $(nav).animate( {    //on veut scroller sur le doc html
        scrollTop: pos  //ben voila, on scroll jusqu'a la position du href :)
    }, {duration:500} );    //et on scroll pas trop vite
    
    return false;   // ! empeche d'aller sur d'autres pages, d'où le "if" qui execute a uniquement si il y a un "#"
});