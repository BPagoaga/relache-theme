<?php include('header.php'); ?>

    <!---------------------------------->
    <!-- zone CONTAINER CORPS DE PAGE -->
    <!---------------------------------->

    <main class="row mentions">

        <div class="col-10 col-center" style="margin-top: 30px; padding-bottom: 20px">
          
            <h1>Mentions légales du site relache</h1>
              
            <h2>Propriétaire et éditeur du site relache</h2>
            
            <p>Le site internet <strong>Relache</strong> accessible à l'adresse <strong>www.relache.fr</strong> ou <strong>www.relâche.fr</strong> est la propriété de l'association <strong>Allez Les Filles</strong> dont le siège est situé 9 Rue Teulière 33000 à <strong>Bordeaux</strong>. <br>
                <strong>Allez Les Filles</strong> est une association à but non lucrative (statut loi 1901) de promotion des musiques alternatives et cultures émergentes, défendant l’accès à la culture pour tous. <br>
                Identifiée sous l'acronyme ADMAA <strong>Association de Défense des Musiques Alternatives en Aquitaine</strong> <br>
                Tel Accueil : 09.83.32.31.69 <br>
                Tel Administration : 05.56.81.64.83 <br>
                Le directeur de la publication du site web est Maxime Morcelet.<br>
            </p>
           
            <h2>Hébergement du site relache</h2>
                
            <p>Le site est hébergé par la société <strong>OVH</strong> <br>
                SAS au capital de 10 059 500 € <br>
                RCS Lille Métropole 424 761 419 00045 <br>
                Code APE 6202A <br>
                N° TVA : FR 22 424 761 419 <br>
                Siège social : 2 rue Kellermann - 59100 Roubaix - France. <br>
            </p>
        
            <h2>Propriété intellectuelle du site relache</h2>
                
            <p>L'ensemble de ce site relève des législations françaises et internationales sur le droit d'auteur et la propriété intellectuelle. Tous les droits de reproduction sont réservés, y compris pour les documents iconographiques et photographiques. <br>
    Le site est réalisé par ROBIN CLIDI, BERNARD PAGOAGA et THIERRY SEBAÏCI (DIGITAL CAMPUS) <br>
                La structure générale, ainsi que les logiciels, textes, images animées ou non sont savoir faire, et tous autres éléments composants le site sont la propriété exclusive de <strong>Allez Les Filles</strong>.<br>
    Toute représentation totale ou partielle de ce site par quelque procédé que ce soit, sans l'autorisation expresse de <strong>Allez Les Filles</strong> est interdite et constituerait une contrefaçon sanctionnée par les articles L.335-2 et suivants du Code de la propriété intellectuelle.<br>
    Il en est de même des bases de données figurant sur le site web, qui sont protégées par les dispositions du Code de la propriété intellectuelle portant transposition de la directive européenne du 11 mars 1996 relative à la protection juridique des bases de données.

            </p>
                
            <h2>Accès au site Internet relache</h2>
            
            <p>L'utilisateur du présent site reconnaît disposer de la compétence et des moyens nécessaires pour accéder et utiliser à ce site et avoir vérifié que la configuration informatique utilisée ne contient aucun virus et qu'elle est en parfait état de fonctionnement.<br>
                L'utilisateur reconnaît avoir été informé que le présent site est accessible 24 heures sur 24 et 7 jours sur 7, à l'exception des cas de force majeure, difficultés liées aux réseaux de communication ou difficultés techniques.<br>
    <strong>Relache</strong> met tout en oeuvre pour offrir aux utilisateurs des informations et/ou outils disponibles et vérifiés, mais ne saurait être tenu responsable des erreurs, d'une absence de disponibilité des informations.<br>
                Tout utilisateur ou visiteur du site web ne peut mettre en place un hyperlien en direction de ce site sans l'autorisation expresse et préalable de <strong>Allez Les Filles</strong>. 
            </p>

            <div class="center">
                <a href="index.php" class="btn">Retour à l'accueil</a>
            </div>
            
         </div>

     </main>
         
    <!---------------------------------->
    <!-- zone FOOTER BAS DE PAGE      -->
    <!---------------------------------->
    
<?php include('footer.php'); ?>