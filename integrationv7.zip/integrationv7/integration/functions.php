<?php 

	/*======================
	 * CONNECTION A LA BDD *
	 ======================*/ 

	function connection(){

		$dsn = 'mysql:host=localhost;dbname=relachefeobdd';
		$user = 'root';
		$password = '';

		try{

			$bdd = new PDO($dsn, $user, $password, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));

		}catch( Exception $e ){
			die('Erreur : '.$e->getMessage());
		}
			return $bdd;

		}

	/*=======================
	 * AJOUT EMAIL DANS BDD *
	 =======================*/ 


	function add_email($data){
		
		$bdd = connection();	//rappel de la connection à chaque page

		$bdd -> exec('
			INSERT INTO emails (
				id,
				email
				)
			VALUES(
				"",
				"'.$data['email'].'"
				)
			');
	}

	/*=========================================
	 * ON VÉRIFIE QU'IL N'Y A PAS DE DOUBLONS *
	 =========================================*/ 

	function email_exist($data) {

		$bdd = connection();

		$emails = $bdd -> query(
			'SELECT COUNT(email) AS compteur
			FROM emails
			WHERE email = \''.$data['email'].'\''
		);

		$donnees = $emails->fetch();
		$emails->closeCursor();

		if( $donnees['compteur'] === '0' ){
			return true;
		}
	}

	/*=====================
	 * DESINSCRIPTION BDD *
	 =====================*/ 

	function delete_email() {

		$bdd = connection();

	    $delete = $bdd -> exec('
	        DELETE FROM emails
	        WHERE email="'.$_GET['email'].'"
	    ');

        $resultat = $delete -> query($bdd);
        if( $resultat )
            echo '<p>Votre email '.$_GET['email'].' a bien été supprimé de notre base de données</p>';
        else
            echo '<p>Cet email ne figure pas dans notre base de données</p>';

    }


	/*=========================================
	 *      RECUPERER LA PROG DANS LA BDD     *
	 =========================================*/

	function get_prog() {

		$bdd = connection();

		$prog = $bdd->query(
			'SELECT artiste, date, heure, lieux
			FROM testbdd'
		);

		while ($programmation = $prog->fetch()){
			$return[] = $programmation;
		}

		$prog->closeCursor();

		return $return;

	}

	/*=========================================
	 *   RECUPERER LES ARTISTES DANS LA BDD   *
	 =========================================*/


	function get_artiste($art){

		$bdd = connection();	//rappel de la connection à chaque page

		$artiste = $bdd->query(
		 	'SELECT artiste, description, youtube
			FROM artistes
			WHERE artiste="'.$art.'"'		 	
		);

		$return = $artiste->fetch();
		$artiste->closeCursor();

		return $return;
	}

	function get_lieu($lieu){

		$bdd = connection();	//rappel de la connection à chaque page

		$lieu = $bdd->query(
		 	'SELECT lieu, description
			FROM lieux
			WHERE lieu="'.$lieu.'"'		 	
		);

		$return = $lieu->fetch();
		$lieu->closeCursor();

		return $return;
	}




?>