<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="fr"> <!--<![endif]-->
<head>

    <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
            <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Relache 2015, musique indépendante à Bordeaux!</title>

    <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/fonts.css">
            <link rel="stylesheet" href="js/vegas/vegas.css">
                <link rel="stylesheet" href="css/style.css">
                

    <!--<script src="js/modernizr-2.7.2.min.js"></script>-->

</head>

<body>

    <header id="header" class="row" role="banner">

            <!--logo-->
        
        <div class="logorelache col-m-4 col-l-4">
            <a href="index.php">
                <img src="img/relache.svg" alt="Logo Relache">
            </a>
        </div>

            <!--burger et plus-->
        <button class="burger">
            <span></span>
        </button>

        <button class="plus">
            <span></span>
        </button>        
        
            <!--baseline-->
        
        <div class="baseline col-m-5 col-l-4">
            <h1>RELACHE 2015: LA MUSIQUE INDÉPENDANTE À BORDEAUX !</h1>
        </div>
        
            <!--réseaux-->
            
        <div class="reseaux col-m-3">
            <ul>
                <li>
                    <a href="https://www.facebook.com/relachefestival">
                        <img src="img/icons/facebook.svg" alt="facebook relache 2015 bordeaux" target="_blank">
                    </a>
                </li>
                <li>
                    <a href="https://twitter.com/RelacheFestival">
                        <img src="img/icons/twitter.svg" alt="twitter relache 2015 bordeaux" target="_blank">
                    </a>
                </li>
                <li>
                    <a href="https://instagram.com/relachefestival/">
                        <img src="img/icons/instagram.svg" alt="instagram relache 2015 bordeaux" target="_blank">
                    </a>
                </li>
                <li>
                    <a href="#contact">
                        <img src="img/icons/contact.svg" alt="contact relache 2015 bordeaux" target="_blank">
                    </a>
                </li>
            </ul>
        </div>
        
    
        
        <nav>
            
            <ul class="l-nav">
                <li><a href="#">ACCUEIL</a></li>
                <li class="menu-item-relache"><a href="#" >RELACHE</a></li>
                <li class="menu-item-qsn"><a href="#" >CONCEPT</a></li>
                <li><a href="#">BLOG</a></li>
                <li> 
                    <label class="search" for="inpt_search">
                        <input id="inpt_search" type="text" />
                    </label>
                </li>
                
                <!--search form-->
            </ul>
            
            <ul class="l-nav-relache">
                <li><a href="#">PROGRAMMATION</a></li>
                <li><a href="#">LIEUX</a></li>
            </ul>
            
            <ul class="l-nav-qsn">
                <li><a href="#">VALEURS</a></li>
                <li><a href="#">GALERIE</a></li>
            </ul>

           
            
        </nav>

    </header>

    