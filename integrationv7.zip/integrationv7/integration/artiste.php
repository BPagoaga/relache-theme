<?php 

include('functions.php');
include('header.php');

$artiste=get_artiste($_GET['artiste']); //déclaration de la variable $artiste dans laquelle on rentre la ligne de la table 'artistes' ou le champs 'artiste' équivaut au nom de l'artiste passé dans l'url via a href="artiste.php?artiste=..."

?>

	<main role="main" class="artiste" style="font-size: 1rem;">

		
		<?php include('ariane.php'); ?>

		<article class="article-artiste col-12 col-l-4 col-l-offset-1 ">
			
			<h1><?= $artiste['artiste']; ?></h1>

			<p><?= $artiste['description']; ?></p>

			<p>Date - Lieu - Prix</p>

			<p>Partage, invitation à l'évènement fb</p>



		</article>

		<article class="article-video col-12 col-l-5 col-l-offset-1 ">
			<iframe width="100%" height="315" src="https://www.youtube.com/embed/6uWivolO8uc" frameborder="0" allowfullscreen></iframe>
		</article>

	

	</main>

<?php include('footer.php'); ?>