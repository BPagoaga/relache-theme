<?php include('header.php'); ?>

	<main role="main" class="programmation">

		<?php include('ariane.php'); ?>

		<h1>programmation relache 2015</h1>

		<aside class="aside-filtre col-12 col-l-3">
			
			<h2>Filtre Mois / Lieux</h2>

			<section class="filtre-mois">

				<label for="">Choix par mois</label><br>

				<a href="#juin">Juin</a>
				<a href="#juillet">Juillet</a>
				<a href="#aout">Août</a>
				<a href="#septembre">Septembre</a>

			</section>

			<section class="filtre-lieux">
				<div class="button-group filter-button-group">
				  <button data-filter="*">show all</button>
				  <button data-filter=".pierre">pierre</button>
				  <button data-filter=".michel">michel</button>
				  <button data-filter=".chartrons">chartrons</button>
				</div>


				<label for="lieux">Choix par lieux</label><br>

				<input type="checkbox" data-filter="*" name="all" value="all" checked>
				<label for="all">Tous</label>

				<input type="checkbox" data-filter=".michel" name="lieux" value="michel" checked>
				<label for="michel">Place St Michel</label>

				<input type="checkbox" data-filter=".pierre" name="lieux" value="pierre" checked>
				<label for="pierre">Place St Pierre</label>

				<input type="checkbox" data-filter=".quinconces" name="lieux" value="quinconces" checked>
				<label for="aout">Place des Quinconces</label>

				<input type="checkbox" data-filter=".chartrons" name="lieux" value="chartrons" checked>
				<label for="septembre">Quai des Chartrons</label>

			</section>

		</aside>

		<article class="article-programmation col-12 col-l-8 col-l-offset-1">
			
			<h2>Liste des évènements</h2>

	<!-- ====== JUIN ===== -->
			
			<h3 id="juin">Juin</h3>

			<div class="row">

				<label class="jour col-l-1">14</label>

				<div class="evenement juin michel col-12 col-m-4 col-l-3">

					<img src="img/relache.svg" alt="" width="150px">

					<p>Artiste - Lieu - Date - Horaire - Description</p>

				</div>

				<div class="evenement juin quinconces col-12 col-m-4 col-l-3">

					<img src="img/relache.svg" alt="" width="150px">

					<p>Artiste - Lieu - Date - Horaire - Description</p>

				</div>

				<div class="evenement juin chartrons col-12 col-m-4 col-l-3">

					<img src="img/relache.svg" alt="" width="150px">

					<p>Artiste - Lieu - Date - Horaire - Description</p>

				</div>

		<!-- ====== JUILLET ===== -->

				<h3 id="juillet">Juillet</h3>

				<label class="jour col-l-1">14</label>

				<div class="evenement juillet pierre col-12 col-m-4 col-l-3">

					<img src="img/relache.svg" alt="" width="150px">

					<p>Artiste - Lieu - Date - Horaire - Description</p>

				</div>

				<div class="evenement juillet michel col-12 col-m-4 col-l-3">

					<img src="img/relache.svg" alt="" width="150px">

					<p>Artiste - Lieu - Date - Horaire - Description</p>

				</div>

				<div class="evenement juillet chartrons col-12 col-m-4 col-l-3">

					<img src="img/relache.svg" alt="" width="150px">

					<p>Artiste - Lieu - Date - Horaire - Description</p>

				</div>

		<!-- ====== AOÛT ===== -->

				<h3 id="aout">Août</h3>

				<label class="jour col-l-1">14</label>

				<div class="evenement aout pierre col-12 col-m-4 col-l-3">

					<img src="img/relache.svg" alt="" width="150px">

					<p>Artiste - Lieu - Date - Horaire - Description</p>

				</div>

				<div class="evenement aout michel col-12 col-m-4 col-l-3">

					<img src="img/relache.svg" alt="" width="150px">

					<p>Artiste - Lieu - Date - Horaire - Description</p>

				</div>

				<div class="evenement aout quinconces col-12 col-m-4 col-l-3">

					<img src="img/relache.svg" alt="" width="150px">

					<p>Artiste - Lieu - Date - Horaire - Description</p>

				</div>

		<!-- ====== SEPTEMBRE ===== -->

				<h3 id="septembre">Septembre</h3>

				<label class="jour col-l-1">14</label>

				<div class="evenement septembre chartrons col-12 col-m-4 col-l-3">

					<img src="img/relache.svg" alt="" width="150px">

					<p>Artiste - Lieu - Date - Horaire - Description</p>

				</div>

				<div class="evenement septembre michel col-12 col-m-4 col-l-3">

					<img src="img/relache.svg" alt="" width="150px">

					<p>Artiste - Lieu - Date - Horaire - Description</p>

				</div>

				<div class="evenement septembre pierre col-12 col-m-4 col-l-3">

					<img src="img/relache.svg" alt="" width="150px">

					<p>Artiste - Lieu - Date - Horaire - Description</p>

				</div>

			</div>

		</article>

	</main> <!-- fin main -->

<?php include('footer.php'); ?>