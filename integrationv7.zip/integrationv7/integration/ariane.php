
<nav class="ariane col-12">

    <ol itemscope itemtype="http://schema.org/BreadcrumbList">

      <li itemprop="itemListElement" itemscope
          itemtype="http://schema.org/ListItem">

        <a itemprop="item" href="index.php">
          <span itemprop="name" class="fa fa-home"></span>
        </a>

        <meta itemprop="position" content="1" />

      </li>
    › 
      <li itemprop="itemListElement" itemscope
          itemtype="http://schema.org/ListItem">
        
          <span itemprop="name">Relache</span>
        

        <meta itemprop="position" content="2" />

      </li>
    ›
      <li itemprop="itemListElement" itemscope
          itemtype="http://schema.org/ListItem">

        <a itemprop="item" href="programmation.php">
          <span itemprop="name">Programmation</span>
        </a>

        <meta itemprop="position" content="3" />

      </li>

    </ol>

</nav>


