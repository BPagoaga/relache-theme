<!DOCTYPE html>
<html lang="fr">
<head>

    <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Relache 2015 Bordeaux : Désabonnement</title>

    <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/fonts.css">
            <link rel="stylesheet" href="css/style.css">
        

</head>

<body>
    
    <header role='banner'>

        <div class="row">

            <div class="datelogo col-10 col-center col-m-5 col-l-4">

                <a href="index.html">

                    <img src="img/typodate.svg" alt="Date et logo Relache 2015">

                </a>

            </div>

            <ul class="reseaux col-5 col-center col-m-3 col-l-2">

                <li>
                    <a href="https://www.facebook.com/relachefestival?fref=ts" target="_blank">
                        <img src="img/icons/facebook.svg" alt="Relache 2015 facebook">
                    </a>
                </li>
                <li>
                    <a href="https://twitter.com/RelacheFestival?lang=fr" target="_blank">
                        <img src="img/icons/twitter.svg" alt="Relache 2015 twitter">
                    </a>
                </li>
                <li>
                    <a href="https://instagram.com/relachefestival/" target="_blank">
                        <img src="img/icons/instagram.svg" alt="Relache 2015 instagram">
                    </a>
                </li>

            </ul>

        </div>

    </header>

    <main>

        <div class="row">

            <div class="col-6 col-center" style="text-align: center; margin-top: 30px; padding-bottom: 20px">

                <?php 

                    include('functions.php');

                    delete_email();

                ?>

                <br>

                <a href="index.html" class="btn">Retour à l'accueil</a>

            </div>

        </div>

    </main>

    <footer class=" col-8 col-s-7 col-m-4 col-l-3 col-xl-2 col-center">

        <p>

        <a href="mailto:com@allezlesfilles.com">com@allezlesfilles.com</a><br>
        -<br>
            
        &copy; Copyright 2015 <a href="http://www.allezlesfilles.net/" target="_blank">Allez Les Filles</a><br>
        
        
        <a href="mentions.html">Mentions légales</a>

    </p>

    </footer>

</body>

</html>